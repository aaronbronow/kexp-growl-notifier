//
//  main.m
//  PopoverExample
//
//  Created by Vladimir Stanciu on 10/24/11.
//  Copyright (c) 2011 Sistronic. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
