//
//  PopoverExampleTests.m
//  PopoverExampleTests
//
//  Created by Vladimir Stanciu on 10/24/11.
//  Copyright (c) 2011 Sistronic. All rights reserved.
//

#import "PopoverExampleTests.h"

@implementation PopoverExampleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in PopoverExampleTests");
}

@end
