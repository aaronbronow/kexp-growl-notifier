//
//  PopoverExampleTests.h
//  PopoverExampleTests
//
//  Created by Vladimir Stanciu on 10/24/11.
//  Copyright (c) 2011 Sistronic. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface PopoverExampleTests : SenTestCase

@end
